%%ecgnoiseBL
load('ecg_noiseBL.mat');
Fs=5180;
t= (0:length(ecg)-1)/Fs;
plot(t,ecg);
xlabel('Time (s)')
ylabel('Ecg amplitude(mV)')
title('Signal ecgnoiseBL')
figure();
y=fft(ecg);
plot(abs(y));
xlabel('Frequency (Hz)')
ylabel('Ecg amplitude(mV)')
title('PS Signal ecgnoiseBL')
figure();

%%chebychev filter
Fc=50;
[b,a] = cheby1(6,10,Fc/(Fs/2),'high');
[h1,w1]=freqz(b,a);
plot(w1/pi,20*log10(abs(h1)),'k','linewidth',2);
xlabel('Normalized frequency')
ylabel('Magnitude')
title('Chebychev Filter')
figure();
plot(t,filter(b,a,ecg));
xlabel('Time(s)')
ylabel('Ecg amplitude(mV)')
title('Filtered ecgnoiseBL')
figure();
s=fft(filter(b,a,ecg));
plot(abs(s));
xlabel('Frequency (Hz)')
ylabel('Ecg amplitude(mV)')
title('PS Filtered ecgnoiseBL')
figure();
