%%ecgnoisePL

load('ecg_noisePL.mat');
Fs=5180;
t= (0:length(ecg)-1)/Fs;
plot(t,ecg);
xlabel('Time(s)')
ylabel('Ecg amplitude(mV)')
title('Signal ecgnoisePL')
figure();
y=fft(ecg);
plot(abs(y));
xlabel('Frequency (Hz)')
ylabel('Ecg amplitude(mV)')
title('PS Signal ecgnoiseBL')
figure();

%%butterworth filter

wn=1;
Fc=50;
[b,a] = butter(wn, Fc/(Fs/2),'low');
[h1,w1]=freqz(b,a);
plot(w1/pi,20*log10(abs(h1)),'k','linewidth',2);
xlabel('Normalized Frequency')
ylabel('Magnitude')
title('Butterworth Filter')
figure();
plot(t,filter(b,a,ecg));
xlabel('Time(s)')
ylabel('Ecg amplitude(mV)')
title('Filtered ecgnoisePL')
figure();
s=fft(filter(b,a,ecg));
plot(abs(s));
xlabel('Frequency (Hz)')
ylabel('Ecg amplitude(mV)')
title('PS Filtered ecgnoisePL')
figure();


