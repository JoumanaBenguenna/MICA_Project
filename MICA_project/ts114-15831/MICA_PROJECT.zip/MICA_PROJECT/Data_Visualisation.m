%% Paramètres
clear;
close all;
clc;

%% Settings
d=50;
N=100;
N_fft=2^nextpow2(N);
w=hamming(N);
ecg=load('ecg_normal_1.mat');
x=ecg(1).ecg; %Signal
Fs=ecg(1).Fs;




% [X, f, t]=stft(x,w,d,N_fft,Fs);
[Sx, f, t]=spectro(x,w,d,N_fft,Fs);
spectre=Sx;

figure()
imagesc(t, f, 20*log10(Sx));
xlabel('Time in s')
ylabel('Frequency in Hz')
title('Spectrogram ecg')



figure()
plot(t,x);
xlabel('Time in s')
ylabel('Amplitude')

%% 

%PQRST
[indices_R,indices_Q,indices_S,seuil] = QRS(x,Fs);
% [P,T] = PTdetection(indices_R,indices_S,indices_Q,x); % ne fonctionne pas

%if this appears:"Unable to perform assignment because the left and right
%sides have a different number of elements." change x into -x.

%Heart BPM

rc=zeros(1,length(indices_R));
ectopic=0;
somme=0;
for kk=1:1:length(indices_R)-1
    delta_N=indices_R(kk+1)-indices_R(kk);
    rc(1,kk)=delta_N;
    somme=somme+rc(kk);
    if (abs(delta_N)>=seuil)
        ectopic=ectopic+1;
    end
end


rythme_card=(somme/length(indices_R))-100;



%Brachicardia and Tachicardia
if rythme_card <=60
    disp(' Arrhythmia detected: Brachicardia ');
end
if rythme_card>=100
    disp('Arrhythmia detected: Tachicardia');
end












